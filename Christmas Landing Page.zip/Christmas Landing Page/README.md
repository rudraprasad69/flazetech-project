# Responsive Christmas Landing Page

- Created a Christmas Landing Page with a Responsive Design utilizing HTML, CSS, and JavaScript.
- Incorporate scrolling animations and enable smooth scrolling within each section.
- Provide users with the option to switch between dark and light mode.
- Ensure compatibility with all mobile devices and design a beautiful and user-friendly interface.
- Compatible with all mobile devices and features..
- Its Mandatory To Use Internet While Run The Code.